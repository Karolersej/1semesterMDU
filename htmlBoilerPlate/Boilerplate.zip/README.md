# HTML Boilerplate

Kopier filerne i denne mappe til dine projekter. Det giver en nem start, hvor strukturen med HTML og CSS er på plads fra begyndelsen.
